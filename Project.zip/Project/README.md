# HelpMeHike

MainActivity corresponds to Screen2

Recorded GPS coordinates are currently fixed to some location in Silicon Valley (when run off Ethan's laptop) but expect will work on a mobile device
